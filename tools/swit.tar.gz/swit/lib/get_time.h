#ifndef _GET_TIME_H_
#define _GET_TIME_H_

#ifdef __cplusplus
extern "C" {
#endif

#define USECS_PER_SEC 1000000

double get_time_wall (void);

double get_time_rusage (void);

#ifdef __cplusplus
}
#endif

#endif /* _GET_TIME_H_ */
