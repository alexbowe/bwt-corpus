#ifndef _IO_H_
#define _IO_H_

#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>

ssize_t writen (int, const void*, size_t);

ssize_t readn (int, void*, size_t);

char *load_text (const char*, uint64_t*);

void fputs_pretty (const char*, FILE*);

void fputc_pretty (const int, FILE*);

#endif /* _IO_H_ */
