#include "error.h"
#include "io.h"
#include "word.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

struct word *word_new (uint32_t id, const char *str, uint32_t length)
{
    struct word *word;

    word = malloc(sizeof(struct word));
    assert_err(word != NULL);

    word->length = length;

    word->id = id;

    word->str = malloc(length + 1);
    assert_err(word->str != NULL);

    memcpy(word->str, str, length);

    word->str[length] = 0;

    word->next = NULL;

    return word;
}

void word_free (struct word *word)
{
    if (word->next != NULL)
        word_free(word->next);

    free(word->str);
    free(word);
}

void word_print (struct word *word, FILE *stream)
{
    uint32_t i;
    for (i = 0; i < word->length; i++)
        fputc(word->str[i], stream);
}

int word_cmp_id (const void *v1, const void *v2)
{
    struct word *w1 = (struct word *)v1;
    struct word *w2 = (struct word *)v2;

    if (w1->id < w2->id)
        return -1;
    else if (w1->id > w2->id)
        return 1;

    return 0;
}

struct word *word_read_fp (FILE *fp)
{
    struct word *word;
    size_t nitems;

    word = malloc(sizeof(struct word));
    assert_err(word != NULL);

    nitems = fread(&word->length, sizeof word->length, 1, fp);
    assert_err(nitems == 1);

    word->str = malloc(word->length + 1);
    assert_err(word->str != NULL);

    nitems = fread(word->str, word->length, 1, fp);
    assert_err(nitems == 1);

    word->str[word->length] = 0;

    nitems = fread(&word->id, sizeof word->id, 1, fp);
    assert_err(nitems == 1);

    word->next = NULL;

    return word;
}

void word_write_fp (struct word *word, FILE *fp)
{
    size_t nitems;

    nitems = fwrite(&word->length, sizeof word->length, 1, fp);
    assert_err(nitems == 1);

    nitems = fwrite(word->str, word->length, 1, fp);
    assert_err(nitems == 1);

    nitems = fwrite(&word->id, sizeof word->id, 1, fp);
    assert_err(nitems == 1);
}
