#include "error.h"
#include "get_time.h"
#include "io.h"
#include "parser.h"
#include "word.h"
#include "word_map.h"

#include <assert.h>
#include <inttypes.h>
#include <locale.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char **argv)
{
    struct word_map *word_map;
    struct word *word;

    uint32_t prev_token_was_a_word; // my favourite variable names evarrrR1!
    uint32_t curr_token_is_a_word;

    uint32_t u32;

    FILE *fp;

    double start_wall;
    double start_rusage;

    setlocale(LC_NUMERIC, "");

    if (argc != 3) {
        fprintf(stderr,
                "usage: %s <translated_file> <word_map>\n",
                argv[0]);
        exit(EXIT_FAILURE);
    }

    fp = fopen(argv[1], "rb");
    assert_err(fp != NULL);

    word_map = word_map_load(argv[2]);

    word_map_sort_by_id(word_map);

    start_wall = get_time_wall();
    start_rusage = get_time_rusage();

    prev_token_was_a_word = 0;

    while (fread(&u32, sizeof u32, 1, fp) > 0) {
        word = word_map_fetch_id(word_map, u32);

        curr_token_is_a_word = INAWORD(word->str[0]);

        if (prev_token_was_a_word == 1 && curr_token_is_a_word == 1)
            fputc(' ', stdout);

        word_print(word, stdout);

        prev_token_was_a_word = curr_token_is_a_word;
    }

    word_map_free(word_map);

    fclose(fp);

    fprintf(stderr, "run time (wall)    : %'.6f\n"
                    "run time (usr+sys) : %'.6f\n",
            get_time_wall() - start_wall,
            get_time_rusage() - start_rusage);

    return EXIT_SUCCESS;
}
