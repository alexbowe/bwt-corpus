#include "error.h"
#include "word.h"
#include "word_map.h"

#include <assert.h>
#include <limits.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

struct word_map {
    struct word **hash;
    uint32_t size;
    uint32_t nchains;
    uint32_t ndistinct;
    uint64_t ninsertions;
    uint64_t nbytes_used;
};

struct word_map *word_map_init (uint32_t size)
{
    struct word_map *word_map;
    uint32_t i;

    word_map = malloc(sizeof(struct word_map));
    assert_err(word_map != NULL);

    word_map->size = size;

    word_map->hash = malloc(word_map->size * sizeof(struct word*));
    assert_err(word_map->hash != NULL);

    for (i = 0; i < word_map->size; i++)
        word_map->hash[i] = NULL;

    word_map->nchains = 0;
    word_map->ndistinct = 0;
    word_map->ninsertions = 0;

    word_map->nbytes_used =
        sizeof(struct word_map) + (word_map->size * sizeof(struct word*));

    return word_map;
}

void word_map_free (struct word_map *word_map)
{
    uint32_t i;

    for (i = 0; i < word_map->size; i++) {
        if (word_map->hash[i] == NULL)
            continue;

        word_free(word_map->hash[i]);
    }

    free(word_map->hash);
    free(word_map);
}

void word_map_statistics (struct word_map *word_map, FILE *stream)
{
    fprintf(stream, "ninsertions          : %'"PRIu64"\n",
            word_map->ninsertions);

    fprintf(stream, "distinct words       : %'d\n",
            word_map->ndistinct);

    fprintf(stream, "number of chains     : %'d\n",
            word_map->nchains);

    fprintf(stream, "hash size            : %'d ptrs (%d MB)\n",
            word_map->size,
            (uint32_t)((word_map->size * sizeof(void*)) / 1024.0/ 1024.0));

    fprintf(stream, "memory used          : %'d MB\n",
            (uint32_t)(word_map->nbytes_used / 1024.0 / 1024.0));
}

/*
 * Paul Hsieh's string hashing function modified to suit my needs.
 * NEVER try to write your own hash function unless you have a
 * few years to waste ...
 * http://www.azillionmonkeys.com/qed/hash.html
 *
 */

#undef get16bits
#if (defined(__GNUC__) && defined(__i386__)) || defined(__WATCOMC__) \
  || defined(_MSC_VER) || defined (__BORLANDC__) || defined (__TURBOC__)
#define get16bits(d) (*((const short *) (d)))
#endif
#if !defined (get16bits)
#define get16bits(d) ((((const unsigned char *)(d))[1] << UINT32_C(8))\
                      +((const unsigned char *)(d))[0])
#endif

static uint32_t word_map_hashfn (const char *buf, uint32_t len, uint32_t max)
{
    uint32_t tmp, result;
    int rem;

    result = len;

    if ((len <= 0) || (buf == NULL)) return 0;

    rem = len & 3;
    len >>= 2;

    /* Main loop */
    for (; len > 0; len--) {
        result  += get16bits (buf);
        tmp      = (get16bits (buf + 2) << 11) ^ result;
        result   = (result << 16) ^ tmp;
        buf     += 2 * sizeof (unsigned short);
        result  += result >> 11;
    }

    /* Handle end cases */
    switch (rem) {
    case 3:
        result += get16bits (buf);
        result ^= result << 16;
        result ^= buf[sizeof (unsigned short)] << 18;
        result += result >> 11;
        break;
    case 2:
        result += get16bits (buf);
        result ^= result << 11;
        result += result >> 17;
        break;
    case 1:
        result += *buf;
        result ^= result << 10;
        result += result >> 1;
    }

    /* Force "avalanching" of final 127 bits */
    result ^= result << 3;
    result += result >> 5;
    result ^= result << 4;
    result += result >> 17;
    result ^= result << 25;
    result += result >> 6;

    /* return  ( int_hash ( result ) & ( max - 1 ) ); */
    return  ((result) % (max - 1));
}

struct word *word_map_lookup (struct word_map *word_map,
                              const char *buf,
                              uint32_t length)
{
    struct word *curr;
    struct word *prev;
    uint32_t h;

    h = word_map_hashfn(buf, length, word_map->size);

    prev = NULL;
    curr = word_map->hash[h];

    while (curr != NULL) {
        if ((curr->length == length) &&
            (memcmp(curr->str, buf, length) == 0))
            break;

        prev = curr;
        curr = curr->next;
    }

    // move to front

    if ((prev != NULL) && (curr != NULL)) {
        prev->next = curr->next;
        curr->next = word_map->hash[h];
        word_map->hash[h] = curr;
    }

    return curr;
}

struct word *word_map_insert (struct word_map *word_map,
                              const char *buf,
                              uint32_t length)
{
    struct word *w;
    uint32_t h;

    w = word_map_lookup(word_map, buf, length);

    // link to front

    if (w == NULL) {
        w = word_new(word_map->ndistinct, buf, length);

        word_map->nbytes_used += sizeof(struct word) + length + 1;

        h = word_map_hashfn(w->str, length, word_map->size);

        if (word_map->hash[h] == NULL)
            word_map->nchains++;

        w->next = word_map->hash[h];

        word_map->hash[h] = w;

        word_map->ndistinct++;

        assert(word_map->ndistinct < UINT32_MAX);
    }

    word_map->ninsertions++;

    return w;
}

void word_map_print (struct word_map *word_map, FILE *stream)
{
    struct word *word;
    uint32_t i;

    for (i = 0; i < word_map->size; i++) {
        word = word_map->hash[i];

        if (word == NULL)
            continue;

        int j = 0;
        while (word != NULL) {
            printf("[%d, %d] ", i, j++);
            word_print(word, stream);
            word = word->next;
        }
    }
}

struct word_map *word_map_load (const char *path)
{
    struct word_map *word_map;
    FILE *fp;

    struct word *word;

    uint32_t wm_size;
    uint32_t wm_nchains;
    uint32_t wm_ndistinct;
    uint64_t wm_ninsertions;
    uint64_t wm_nbytes_used;

    uint32_t h;
    uint32_t i;

    fp = fopen(path, "rb");
    assert_err(fp != NULL);

    fread(&wm_size, sizeof wm_size, 1, fp);
    fread(&wm_nchains, sizeof wm_nchains, 1, fp);
    fread(&wm_ndistinct, sizeof wm_ndistinct, 1, fp);
    fread(&wm_ninsertions, sizeof wm_ninsertions, 1, fp);
    fread(&wm_nbytes_used, sizeof wm_nbytes_used, 1, fp);

    word_map = word_map_init(wm_size);

    for (i = 0; i < wm_ndistinct && !feof(fp); i++) {
        fread(&h, sizeof h, 1, fp);

        word = word_read_fp(fp);

        if (word_map->hash[h] == NULL)
            word_map->nchains++;

        word->next = word_map->hash[h];

        word_map->hash[h] = word;

        word_map->ndistinct++;

        word_map->nbytes_used += sizeof(struct word) + word->length + 1;
    }

    fclose(fp);

    assert_errx(word_map->size == wm_size,
                "invalid hash size, %d != %d",
                word_map->size, wm_size);

    assert_errx(word_map->nchains == wm_nchains,
                "invalid chain count, %d != %d",
                word_map->nchains, wm_nchains);

    assert_errx(word_map->ndistinct == wm_ndistinct,
                "invalid distinct word count %d != %d",
                word_map->ndistinct, wm_ndistinct);

    assert_errx(word_map->nbytes_used == wm_nbytes_used,
                "invalid nbytes count %"PRIu64" != %"PRIu64"",
                word_map->nbytes_used, wm_nbytes_used);

    return word_map;
}

void word_map_save (struct word_map *word_map, const char *path)
{
    struct word *word;
    uint32_t i;
    FILE *fp;

    fp = fopen(path, "wb");
    assert_err(fp != NULL);

    fwrite(&word_map->size, sizeof word_map->size, 1, fp);
    fwrite(&word_map->nchains, sizeof word_map->nchains, 1, fp);
    fwrite(&word_map->ndistinct, sizeof word_map->ndistinct, 1, fp);
    fwrite(&word_map->ninsertions, sizeof word_map->ninsertions, 1, fp);
    fwrite(&word_map->nbytes_used, sizeof word_map->nbytes_used, 1, fp);

    for (i = 0; i < word_map->size; i++) {
        word = word_map->hash[i];

        while (word != NULL) {
            fwrite(&i, sizeof i, 1, fp);

            word_write_fp(word, fp);

            word = word->next;
        }
    }

    fclose(fp);
}

uint64_t word_map_memusage (struct word_map *word_map)
{
    return word_map->nbytes_used;
}

struct word *word_map_fetch_id (struct word_map *word_map, uint32_t id)
{
    assert(word_map->hash[id] != NULL);

    return word_map->hash[id];
}

void word_map_sort_by_id (struct word_map *word_map)
{
    struct word **sorted;
    struct word *word;
    uint32_t size;
    uint32_t id;
    uint32_t i;

    size = word_map->ndistinct;

    sorted = malloc(size * sizeof(struct word*));
    assert_err(sorted != NULL);

    for (i = 0; i < size; i++)
        sorted[i] = NULL;

    for (i = 0; i < word_map->size; i++) {
        if (word_map->hash[i] == NULL)
            continue;

        word = word_map->hash[i];

        while (word != NULL) {
            id = word->id;
            assert(sorted[id] == NULL);
            sorted[id] = word;
            word = word->next;
            sorted[id]->next = NULL; // <3
        }
    }

    free(word_map->hash);

    word_map->hash = sorted;

    word_map->size = size;
}
