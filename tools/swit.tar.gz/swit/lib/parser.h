#ifndef _PARSER_H_
#define _PARSER_H_

#include <ctype.h>
#include <stdint.h>

struct token {
    uint64_t offset;
    uint64_t length;
};

#define INAWORD(c) (isprint(c) && isalnum(c))

void next_token (char*, uint64_t, struct token*);

#endif /* _PARSER_H_ */
