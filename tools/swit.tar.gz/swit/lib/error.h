#ifndef _ERROR_H_
#define _ERROR_H_

#include <stdarg.h>

#ifndef __ASSERT_VOID_CAST
#define __ASSERT_VOID_CAST (void)
#endif

#define assert_err(expr)                                                \
    ((expr)                                                             \
     ? __ASSERT_VOID_CAST (0)                                           \
     : _assert_err (__FILE__, __LINE__, __func__, #expr))

#define assert_errx(expr, format, ...)                                  \
    ((expr)                                                             \
     ? __ASSERT_VOID_CAST (0)                                           \
     : _assert_errx(__FILE__, __LINE__, __func__, #expr, format, ##__VA_ARGS__))

void
_assert_err (const char*, int, const char*, const char*)        \
    __attribute__ ((noreturn));

void
_assert_errx (const char*, int, const char*, const char*, const char*, ...) \
    __attribute__ ((noreturn, format (printf, 5, 6)));

#endif /* _ERROR_H_ */
