#ifndef _WORD_H_
#define _WORD_H_

#include <stdint.h>
#include <stdio.h>

struct word {
    char *str;
    uint32_t length;
    uint32_t id;
    struct word *next;
};

struct word *word_new (uint32_t, const char*, uint32_t);

void word_free (struct word*);

void word_print (struct word*, FILE*);

int word_freq_cmp (const void*, const void*);

struct word *word_read_fp (FILE*);

void word_write_fp (struct word*, FILE*);

#endif /* _WORD_H_ */
