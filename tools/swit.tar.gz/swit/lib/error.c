#include "error.h"

#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void va_print (const char *file,
                      int line,
                      const char *function,
                      const char *expr,
                      const char *format,
                      va_list va,
                      int append_strerror)
{
    char buf[BUFSIZ];
    int errno_save, n;

    errno_save = errno; // all libc/system calls will overwrite errno

    n = snprintf(buf,
                 BUFSIZ,
                 "%s:%d: %s: Assertion `%s' failed : ",
                 file, line, function, expr);

    if (va != NULL) {
        vsnprintf(buf + n, BUFSIZ - n, format, va);

        n = strlen(buf);
    }

    if (append_strerror)
        snprintf(buf + n, BUFSIZ - n, "%s", strerror(errno_save));

    strcat(buf, "\n");

    fflush(stdout); // incase stdout and stderror are the same '2>&1'

    fputs(buf, stderr); // write to stderr without trailing \0

    fflush(stderr);
}

void _assert_err (const char *file,
                  int line,
                  const char *function,
                  const char *expr)
{
    va_print(file, line, function, expr, NULL, NULL, 1);

    exit(EXIT_FAILURE);
}

void _assert_errx (const char *file,
                   int line,
                   const char *function,
                   const char *expr,
                   const char *format,
                   ...)
{
    va_list va;

    va_start(va, format);

    va_print(file, line, function, expr, format, va, 0);

    va_end(va);

    exit(EXIT_FAILURE);
}
