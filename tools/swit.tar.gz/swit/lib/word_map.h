#ifndef _WORD_MAP_H_
#define _WORD_MAP_H_

#include <stdint.h>
#include <stdio.h>

// 1 << 27               : 134217728
// 1 << 26               : 67108864
// wt100g distinct terms : 62990105
// wt10g  distinct terms : 11649697
// wt2g   distinct terms : 2499217

#define DEFAULT_HASH_SIZE (1 << 25) // 128MB 32bits, 256MB 64bits
//#define DEFAULT_HASH_SIZE (1 << 26) // 256MB 32bits, 512MB 64bits

struct word_map;

struct word_map *word_map_init (uint32_t);

void word_map_free (struct word_map*);

void word_map_statistics (struct word_map*, FILE*);

struct word *word_map_lookup (struct word_map*, const char*, uint32_t);

struct word *word_map_insert (struct word_map*, const char*, uint32_t);

void word_map_print (struct word_map*, FILE*);

struct word_map *word_map_load (const char*);

void word_map_save (struct word_map*, const char*);

uint64_t word_map_memusage (struct word_map*);

struct word *word_map_fetch_id (struct word_map*, uint32_t);

void word_map_sort_by_id (struct word_map*);

#endif /* _WORD_MAP_H_ */
