#include "error.h"
#include "get_time.h"

#include <sys/resource.h>
#include <sys/time.h>
#include <time.h>

double get_time_wall ()
{
    struct timeval timeval;
    int ret;

    double time;

    ret = gettimeofday(&timeval, NULL);
    assert_err(ret != -1);

    time =
        (double) timeval.tv_sec +
        (double) timeval.tv_usec / USECS_PER_SEC;

    return time;
}

double get_time_rusage ()
{
    struct rusage rusage;
    double usertime;
    double systime;
    int ret;

    ret = getrusage(RUSAGE_SELF, &rusage);
    assert_err(ret != -1);

    usertime =
        (double) rusage.ru_utime.tv_sec +
        (double) rusage.ru_utime.tv_usec / USECS_PER_SEC;

    systime =
        (double) rusage.ru_stime.tv_sec +
        (double) rusage.ru_stime.tv_usec / USECS_PER_SEC;

    return usertime + systime;
}
