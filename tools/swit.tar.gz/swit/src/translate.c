#include "error.h"
#include "get_time.h"
#include "io.h"
#include "parser.h"
#include "word.h"
#include "word_map.h"

#include <assert.h>
#include <inttypes.h>
#include <locale.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char **argv)
{
    struct word_map *word_map;

    FILE *output_fp;

    char path[BUFSIZ];

    char *buffer;
    uint64_t nbytes;

    struct token token;

    uint64_t ntokens_processed;
    uint64_t spaces_skipped;

    double start_wall;
    double start_rusage;

    struct word *word;
    size_t nitems;

    setlocale(LC_NUMERIC, "");

    if (argc != 2) {
        fprintf(stderr, "usage: %s <file_to_parse>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    word_map = word_map_init(DEFAULT_HASH_SIZE);

    snprintf(path, BUFSIZ, "%s.swit", argv[1]);

    output_fp = fopen(path, "wb");
    assert_err(output_fp != NULL);

    buffer = load_text(argv[1], &nbytes);

    fprintf(stderr, "loaded               : %s, %'"PRIu64"\n",
            argv[1], nbytes);

    ntokens_processed = 0;
    spaces_skipped = 0;

    token.offset = 0;
    token.length = 0;

    start_wall = get_time_wall();
    start_rusage = get_time_rusage();

    while (token.offset < nbytes) {
        next_token(buffer, nbytes, &token);

        ntokens_processed++;

        word = word_map_insert(word_map, buffer + token.offset, token.length);
        assert(word != NULL);

        if (token.length == 1 && buffer[token.offset] == ' ') {
            spaces_skipped++;
        }
        else {
            nitems = fwrite(&word->id, sizeof word->id, 1, output_fp);
            assert_err(nitems == 1);
        }

        token.offset += token.length;
    }

    fclose(output_fp);

    snprintf(path, BUFSIZ, "%s.word_map", argv[1]); // (:

    word_map_save(word_map, path);

    word_map_statistics(word_map, stderr);

    fprintf(stderr, "tokens processed     : %'"PRIu64"\n", ntokens_processed);

    fprintf(stderr, "spaces skipped       : %'"PRIu64"\n", spaces_skipped);

    fprintf(stderr, "run time (wall)      : %'.6f\n"
                    "run time (usr+sys)   : %'.6f\n",
            get_time_wall() - start_wall,
            get_time_rusage() - start_rusage);

    free(buffer);

    word_map_free(word_map);

    return EXIT_SUCCESS;
}
