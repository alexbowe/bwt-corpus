#include "error.h"
#include "parser.h"
#include "word.h"
#include "word_map.h"

#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void next_token (char *buffer, uint64_t nbytes, struct token *token)
{
    uint32_t get_word;

    token->length = 0;

    get_word = INAWORD(buffer[token->offset + token->length]);

    token->length++;

    while (((token->offset + token->length) < nbytes) &&
            (INAWORD(buffer[token->offset + token->length]) == get_word)) {
        token->length++;
    }
}
