#include "error.h"
#include "io.h"

#if defined HAVE_ZLIB
#include "zlib.h"
#endif

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

static const uint8_t gzip_header_1 = 0x1f;

static const uint8_t gzip_header_2 = 0x8b;

static int detect_gzip (const char *path)
{
    FILE *fp;
    uint8_t u8;
    size_t nitems;

    fp = fopen(path, "rb");
    assert_err(fp != NULL);

    nitems = fread(&u8, sizeof u8, 1, fp);
    assert_err(nitems == 1);

    if (u8 != gzip_header_1) {
        fclose(fp);
        return -1;
    }

    nitems = fread(&u8, sizeof u8, 1, fp);
    assert_err(nitems == 1);

    if (u8 != gzip_header_2) {
        fclose(fp);
        return -1;
    }

    fclose(fp);

    return 1;
}

#if defined HAVE_ZLIB
static char *read_gz (const char *path, uint64_t *length)
{
    gzFile gzfp;
    int nbytes;

    char *buffer;

    uint64_t nbytes_count;
    uint64_t nbytes_size;

    gzfp = gzopen(path, "rb");
    assert_err(gzfp != NULL);

    nbytes_count = 0;
    nbytes_size = BUFSIZ;

    buffer = malloc(nbytes_size * sizeof(char));
    assert_err(buffer != NULL);

    while (gzeof(gzfp) != 1) {
        if (nbytes_count + BUFSIZ >= nbytes_size) {
            if (nbytes_size > (1<<30)) // once over 1GB use smaller increments
	        nbytes_size += BUFSIZ;
	    else
                nbytes_size <<= 1;

            buffer = realloc(buffer, nbytes_size * sizeof(char));
            assert_err(buffer != NULL);
        }

        nbytes = gzread(gzfp, buffer + nbytes_count, BUFSIZ);
        assert_err(nbytes >= 0);
        if (nbytes == 0)
            break;

        nbytes_count += nbytes;
    }

    buffer[nbytes_count] = 0;

    *length = nbytes_count;

    gzclose(gzfp);

    return buffer;
}
#endif

static char *read_text (const char *path, uint64_t *length)
{
    char *buffer;

    struct stat statb;
    ssize_t nbytes;
    int ret;
    int fd;

    ret = stat(path, &statb);
    assert_err(ret != -1);

    buffer = malloc((statb.st_size + 1) * sizeof(char));
    assert_err(buffer != NULL);

    *length = statb.st_size;

    fd = open(path, O_RDONLY);
    assert_err(fd != -1);

    nbytes = readn(fd, buffer, statb.st_size);
    assert_err(nbytes == statb.st_size);

    buffer[nbytes] = 0;

    close(fd);

    return buffer;
}

ssize_t readn (int fd, void *vptr, size_t n)
{
    size_t nleft;
    ssize_t nread;
    char *ptr;

    ptr = vptr;
    nleft = n;

    while (nleft > 0) {
        if((nread = read(fd, ptr, nleft)) < 0) {
            if(errno == EINTR)
                nread = 0;
            else
                return -1;
        }
        else if (nread == 0)
            break; /* EOF */

        nleft -= nread;
        ptr += nread;
    }

    return (n - nleft);
}

char *load_text (const char *path, uint64_t *length)
{
    struct stat statb;
    char *buffer;
    int ret;

    ret = access(path, F_OK | R_OK);
    assert_err(ret != -1);

    ret = stat(path, &statb);
    assert_err(ret != -1);

    ret = detect_gzip(path);

    if (ret == 1) {
#if defined HAVE_ZLIB
        buffer = read_gz(path, length);
#else
        fprintf(stderr,
                "Error: Can not decode '%s'please install zlib\n",
                path);
        return NULL;
#endif
    }
    else
        buffer = read_text(path, length);

    return buffer;
}

void fputs_pretty (const char *string, FILE *stream)
{
    const char *ptr;
    for (ptr = string; *ptr != '\0' ; ptr++)
        fputc_pretty(*ptr, stream);
}


void fputc_pretty (const int c, FILE *stream)
{
    switch (c) {
    case '\n':
        fputs("\\n", stream);
        break;
    case '\r':
        fputs("\\r", stream);
        break;
    case '\t':
        fputs("\\t", stream);
        break;
    default:
        fputc(c, stream);
        break;
    }
}
